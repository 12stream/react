//other.js
import React, { Component } from 'react';

export default class About extends Component {
  render() {
    return (
    <div>
      欢迎，这里是About的子路由
    </div>
    )
  }
}