//home.js
import React, { Component } from 'react';
import {Link} from 'react-router-dom'
import axios from 'axios'

export default class Home extends Component {
    constructor(props) {
        super(props);
        this.state = {
            show: '这是定义数据'
        }
    }
    componentDidMount() {
        this.getData();
    }
    getData(){
        axios.post('http://192.169.2.35/dsp/userThread/count', {
            })
            .then(function (response) {
            console.log(response);
            })
            .catch(function (error) {
            console.log(error);
        });
    }
    display = () => {
        this.setState({
            show:'这是改变后的定义数据'
        })
    }
  render() {
    return (<h1>
      欢迎，这里是Home
      {this.state.show}
      <Link to="/about">about页面</Link>
      <button onClick={this.display}>改变数据</button>
    </h1>)
  }
}