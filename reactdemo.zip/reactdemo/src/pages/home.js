//home.js
import React, { Component } from 'react';

export default class Home extends Component {
  render() {
    return (<h1>
      欢迎，这里是Home
    </h1>)
  }
}