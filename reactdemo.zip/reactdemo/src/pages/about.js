//about.js
import React, { Component } from 'react';

export default class About extends Component {
  render() {
    return (
    <h1>
      欢迎，这里是About
      {this.props.children}
    </h1>
    )
  }
}