import React, { Component } from 'react';
import Router from './router/router'

class App extends Component {


  constructor(props){

    super(props);
  }
  render() {
    return (
      <div>
        <header>
          这是公共头部
        </header>
        <Router />
      </div>
    );
  }
}

export default App;