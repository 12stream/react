module.exports = {
  apps: [{
    name: "medical_daq_manage",
    script: "./bin/www",
    watch: false,
    exec_mode: "fork",
    instances: 1,
    max_memory_restart: "1G",
    autorestart: true,
    node_args: [],
    args: [],
    env: {
      NODE_ENV: "production"
    }
  }]
}
