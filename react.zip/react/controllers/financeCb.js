/**
 * Created by Administrator on 2017/5/11 0011.
 */
var qs = require('querystring');

exports.Render_goods_form = function(req,res,next){
    var list = req.json;
    var temprary = [];
    if(list.data){
        if(list.data.data || list.data.data.length != 0){
            temprary = list.data.data;
        }
    }
    var query = req.query;
    res.locals.queryObj = query;
    console.log('======queryObj   =========='+query);
    if(req.success){
        delete query.page;
        var queryStr = qs.stringify(query)
        queryStr = queryStr?queryStr+='&':'';
        res.locals.query = queryStr;
        res.render('finance/goods_form',{
            title:'财务报表-套餐购买',
            data:temprary
        })
    }else{
        res.render('finance/goods_form',{
            title:'财务报表-套餐购买',
            data:req.json
        })
    }
}

exports.Render_books_form = function(req,res,next){
    var list = req.json;
    var temprary = [];
    if(list.data){
        if(list.data.data || list.data.data.length != 0){
            temprary = list.data.data;
        }
    }
    var query = req.query;
    res.locals.queryObj = query;
    console.log('======queryObj   =========='+JSON.stringify(query));
    if(req.success){
        delete query.page;
        var queryStr = qs.stringify(query)
        queryStr = queryStr?queryStr+='&':'';
        res.locals.query = queryStr;
        res.render('finance/books_form',{
            title:'财务报表-预约挂号',
            data:temprary
        })
    }else{
        res.render('finance/books_form',{
            title:'财务报表-预约挂号',
            data:req.json
        })
    }
}