/**
 * Created by Administrator on 2017/5/11 0011.
 */

var express =  require('express');
var router = express.Router();
var System = require('./system');
var requests = require('../request/financeReq')
var financeCb = require('./../controllers/financeCb');
var Com = require('./com');

router.get('/goods?',System.loginRequired,Com.get_hospital_all,requests.getAllGoodsList,financeCb.Render_goods_form);

router.get('/books?',System.loginRequired,Com.get_hospital_all,requests.getAllBooksList,financeCb.Render_books_form);

router.get('/outputGoodsExcel',requests.getQueryGoodsList,requests.outputExcelGoods);

router.get('/outputBooksExcel',requests.getQueryBooksList,requests.outputExcelBooks);

module.exports = router


