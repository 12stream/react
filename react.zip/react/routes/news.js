/**
 * 新闻资讯
 **/
var express = require('express')
var jade = require('jade')
var path = require('path')
var async = require('async')
var request = require('../request/newsReq')
var router = express.Router()
var System = require('./system')
var dataDicRequest = require('../request/dataDicReq')

router.get('/list', System.loginRequired, function (req, res, next) {
  req.query.type = 'news_category'
  req.query.level = 1
  req.query.activeState = 1
  dataDicRequest.FetchDataDictCategory(req, function (data, success) {
    var category = JSON.parse(data).data
    request.NewsSearch(req, function (data, success) {
      res.locals.success = success
      if (success) {
        var json = JSON.parse(data)
        var query = req.query
        res.locals.pagecount = json.data.pageCount
        res.locals.currentpage = req.query.page || 1
        delete query.page
        var queryStr = ''
        for (var attr in query) {
          queryStr += attr + '=' + query[attr] + '&'
        }
        res.locals.query = queryStr
        res.locals.category = query.category || '1'
        res.locals.tc = query.tc || ''
        res.locals.status = query.status || ''
        var result = json.data.data
        // var idArr = []
        // var newResult = []
        // if (req.params.category == '' || req.query.category == '') {
        //   for (var i = 0; i < category.length; i++) {
        //     idArr.push(category[i].id)
        //   }
        //   if (result) {
        //     for (var j = 0; j < result.length; j++) {
        //       for (var k = 0; k < idArr.length; k++) {
        //         if (result[j].categoryId == idArr[k]) {
        //           newResult.push(result[j])
        //         }
        //       }
        //     }
        //     result = newResult
        //   }
        // }
        res.render('news/list', {
          title: '新闻资讯_新闻列表',
          data: result,
          tc: query.title || ''
        })
      } else {
        res.render('news/list', {
          title: '新闻资讯_新闻列表',
          data: data
        })
      }
    })
  })
})

router.post('/save', System.loginRequired, function (req, res, next) {
  request.SaveNews(req, function (data, success) {
    res.send(data)
  })
})

router.put('/change/state', System.loginRequired, function (req, res, next) {
  request.ChangeNewsState(req, function (data, success) {
    res.send(data)
  })
})

router.get('/add', System.loginRequired, function (req, res, next) {
  req.query.type = 'news_category'
  req.query.level = 1
  req.query.activeState = 1
  var canEdit = true
  dataDicRequest.FetchDataDictCategory(req, function (data, success) {
    var category = JSON.parse(data).data
    res.render('news/add', {
      title: '新闻资讯-新增新闻',
      category: category,
      canEdit: canEdit
    })
  })
})

router.get('/edit', System.loginRequired, function (req, res, next) {
  var canEdit = true
  req.query.type = 'news_category'
  req.query.level = 1
  req.query.activeState = 1
  dataDicRequest.FetchDataDictCategory(req, function (cdata, success) {
    var category = JSON.parse(cdata).data
    res.locals.category = category
    request.NewsDetailById(req, function (data, success) {
      res.locals.newsData = JSON.parse(data).data
      res.render('news/edit', {
        title: '新闻资讯-编辑新闻',
        canEdit: canEdit
      })
    })
  })
})

router.post('/update', System.loginRequired, function (req, res, next) {
  request.UpdateNews(req, function (data, success) {
    res.send(data)
  })
})

router.get('/detail', System.loginRequired, function (req, res, next) {
  var canEdit = false
  req.query.type = 'news_category'
  req.query.level = 1
  req.query.activeState = 1
  dataDicRequest.FetchDataDictCategory(req, function (cdata, success) {
    var category = JSON.parse(cdata).data
    res.locals.category = category
    request.NewsDetailById(req, function (data, success) {
      res.locals.newsData = JSON.parse(data).data
      res.render('news/edit', {
        title: '新闻资讯-新闻详情',
        canEdit: canEdit
      })
    })
  })
})

router.put('/delete', System.loginRequired, function (req, res, next) {
  request.DeleteNews(req, function (data, success) {
    res.send(data)
  })
})

module.exports = router
