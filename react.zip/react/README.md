医疗行业都安全项目后台管理系统

## UEditor API
http://ueditor.baidu.com/doc/#UE.Editor