/**
 * Created by Administrator on 2017/5/11 0011.
 */
var util = require('../lib/ajax')
var api = require('../lib/api');
var moment = require('moment');
var xlsx = require("node-xlsx");
var fs = require('fs');


//搜索时
exports.getAllGoodsList  = function(req,res,next){
    var query = req.query;
    console.log(query);
    if(query.startTime){
        var starts = new Date(query.startTime.replace(/-/gi,"/")).getTime()
        // console.log(starts);
    }
    if(query.endTime){
        var ends = new Date(query.endTime.replace(/-/gi,"/")).getTime()+86400000;
        // console.log(ends);
    }
    if(req.query){
        var orderReportRequest = {
            startTime:starts || '',
            endTime:ends || '',
            hospitalId:query.hospitalId ,
            payType:query.payType ,
            buyWay:query.buyWay,
        }
    }

    var bizParam = {
        'pageIndex':req.query.page || 1,
        'pageSize': 15,
        'orderReportRequest':orderReportRequest || {}
    }
    // 将搜索条件存下来，方便导出Excel使用
    req.session.queryGoodsBizParam = bizParam;
    util.ajax('GET', 'trade.order.pageReport', req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        req.json = json;
        req.success = res.locals.success = json.success;
        if(json.success){
            if(json.data){
                res.locals.pagecount=json.data.pageCount;
                res.locals.currentpage = json.data.currentPage;
            }
        }
        next();
    })
}

//搜索时
exports.getAllBooksList  = function(req,res,next){
    console.log(req.query);
    var query = req.query;
    if(query.dateStart){
        var start = new Date(query.dateStart.replace(/-/gi,"/")).getTime();
        console.log(start);
    }
    if(query.dateEnd){
        var end = new Date(query.dateEnd.replace(/-/gi,"/")).getTime()+86400000;
        console.log(end);
    }
    if(req.query){
        var condition = {
            dateStart:start || '',
            dateEnd:end || '',
            hospitalId:query.hospitalId ,
            payWay:query.payWay ,
            orgType:query.orgType
        }
    }
    var bizParam = {
        'currentPage':req.query.page || 1,
        'pageSize': 15,
        'condition': condition || {}
    }
    req.session.queryBooksBizParam =  bizParam;
    util.ajax('GET', 'schedule.orderpay.page', req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        req.json = json;
        req.success = res.locals.success = json.success;
        if(json.success){
            if(json.data){
                res.locals.pagecount=json.data.pageCount;
                res.locals.currentpage = json.data.currentPage;
            }
        }
        next();
    })
}

// 导出Excel 得到查询的数据
exports.getQueryGoodsList  = function(req,res,next){
    //  拿到存储在session中的参数
    var queryGoodsBizParam = req.session.queryGoodsBizParam;
    queryGoodsBizParam.pageSize = 100000;
    console.log('goods query condition ----------------------->')
    console.log(queryGoodsBizParam);
    util.ajax('GET', 'trade.order.pageReport', req, queryGoodsBizParam, function (data, success){
        var json = JSON.parse(data);
        if(json.success){
            req.queryGoodsData = json;
        }
        next();
    })

}

// 导出Excel 得到查询的数据
exports.getQueryBooksList  = function(req,res,next){
    var queryBooksBizParam = req.session.queryBooksBizParam;
    queryBooksBizParam.pageSize = 100000;
    console.log('books query condition ----------------------->')
    console.log(queryBooksBizParam);
    util.ajax('GET', 'schedule.orderpay.page', req, queryBooksBizParam, function (data, success) {
        var json = JSON.parse(data);
        if(json.success){
            req.queryBooksData = json;
        }
        next();
    })
}

//套餐购买导出Excel
exports.outputExcelGoods = function(req,res,next){
    // 拿到存在Session中的数据
    var queryGoodsData = req.queryGoodsData;
    // console.log(queryGoodsData.data);
    var tempData = dealWithGoodsData(queryGoodsData.data.data);
    // var first = ['收款日期','门诊','订单号','套餐名称','使用密码','预约号','价格','实收金额','购买渠道','支付方式'];
    // var dealWithData = tempData.unshift(first);
    var fileName = new Date().getTime().toString();
    // var  data = [[1,2,"数据一行\r\n数据二行"], [true, false, null, 'sheetjs'], ['foo', '1705161120326837494-1705151602345156186', new Date('2014-02-19T14:30Z'), '0.3']];
    // var  data = [[1,2,"数据一行&#10;数据二行"], [true, false, null, 'sheetjs'], ['foo', '1705161120326837494-1705151602345156186', new Date('2014-02-19T14:30Z'), '0.3']];
    var buffer = xlsx.build([{
        name: "套餐购买",
        data: tempData
    }]);
    // res.setHeader('Content-disposition', 'attachment; filename=' + fileName+'.xlsx');
    // res.send(buffer);
    // res.write(buffer);
    res.attachment(fileName+'.xlsx')
    res.end(buffer);
}

//预约挂号导出Excel
exports.outputExcelBooks = function(req,res,next){
    // 拿到存在Session中的数据
    var queryBooksData = req.queryBooksData
    // console.log(queryBooksData);
    // res.send(queryBooksData);
    var tempData = dealWithBooksData(queryBooksData.data.data);
    // var first = ['收款日期','门诊','订单号','套餐名称','使用密码','预约号','价格','实收金额','购买渠道','支付方式'];
    // var dealWithData = tempData.unshift(first);
    var fileName = new Date().getTime().toString();
    // var  data = [[1, 2, 3], [true, false, null, 'sheetjs'], ['foo', '1705161120326837494-1705151602345156186', new Date('2014-02-19T14:30Z'), '0.3'], ['baz', null, 'qux']];
    var buffer = xlsx.build([{
        name: "预约挂号",
        data: tempData
    }]);
    // res.setHeader('Content-disposition', 'attachment; filename=' + fileName+'.xlsx');
    // res.send(buffer);
    // res.write(buffer);
    res.attachment(fileName+'.xlsx')
    res.end(buffer);
}

function dealWithGoodsData(json){
    var buyWayListShow = ['','APP','官网','微信公众号'];
    var payTypeListShow = ['','支付宝App','微信App','','支付宝PC','支付宝WAP','微信扫码','微信公众号','优惠券'];
    var bigList = [];
    bigList.push(['收款日期','门诊','订单号','套餐名称','使用密码','预约号','价格','实收金额','购买渠道','支付方式']);
    json.forEach(function(item,index){
        console.log('-------->?'+index);
        console.log(JSON.stringify(bigList));
        var list = [];
        list.push(moment(item.payTime).format('YYYY-MM-DD'));
        list.push(item.hospitalName);
        list.push(item.orderId);
        var DTOlist = item.orderItemReportDTOList;
        var goodsNameList ='' ;
        var reservationPwdList ='' ;
        var reservationIdList ='' ;
        var dealPriceList ='' ;
        DTOlist.forEach(function(bux,i){
            console.log(bux);
            console.log(i);
            goodsNameList += bux.goodsName +'\r';
            reservationPwdList += bux.reservationPwd +'\r';
            var shrink = bux.reservationId?bux.reservationId:'-';
            reservationIdList += shrink +'\r';
            dealPriceList += (bux.dealPrice/100).toFixed(2) + '\r';
        })
        console.log(reservationIdList);
        list.push(goodsNameList);
        list.push(reservationPwdList);
        list.push(reservationIdList);
        list.push(dealPriceList);
        list.push((item.totalCost/100).toFixed(2));
        list.push(buyWayListShow[item.buyWay]);
        list.push(payTypeListShow[item.payType]);
        bigList.push(list);
    })
    return bigList;
}

function dealWithBooksData(json){
    var orgTypeListShow = ['','APP','官网','微信公众号'];
    var payWayListShow = ['','支付宝App','微信App','','支付宝PC','支付宝WAP','微信扫码','微信公众号','优惠券'];
    var bigList = [];
    bigList.push(['收款日期','就诊门诊','预约号','预约医生','挂号费','实收金额','挂号渠道','支付方式']);
    json.forEach(function(item,index){
        var list = [];
        list.push(moment(item.payTime).format('YYYY-MM-DD'));
        list.push(item.hospitalName);
        list.push(item.registrationId);
        list.push(item.doctorName);
        list.push((item.cost/100).toFixed(2));
        list.push((item.payAmount/100).toFixed(2));
        list.push(orgTypeListShow[item.orgType]);
        list.push(payWayListShow[item.payWay]);
        bigList.push(list);
    })
    return bigList;
}
