var util = require('../lib/ajax')
var api = require('../lib/api')
var config = require('../config')
var staticize = require('../lib/staticize')
var path = require('path')

exports.NewsSearch = function (req, callback) {
  var query = req.query
  var currentPage = query.page || 1

  if (typeof query.status === 'undefined') {
    query.status = '1'
  }

  if (typeof query.category === 'undefined' || query.category == 'all') {
    query.category = ''
  }

  var newsDTO = {
    // 全部时不用传ID
    'categoryId': query.category || '',
    'title': query.title || '',
    'status': query.status || ''
  }

  var bizParam = {
    'newsDTO': newsDTO,
    'pageStart': currentPage,
    'pageSize': query.pageSize || 10
  }

  util.ajax('GET', api.NewsListSearch, req, bizParam, function (data, success) {
    callback && callback(data, success)
  })
}

exports.SaveNews = function (req, callback) {
  var bizParam = {}
  delete req.body.parentId
  delete req.body.displayOrder
  bizParam.news = req.body
  bizParam.news.categoryId = req.body.category
  bizParam.news.image = req.body.imgs
  // bizParam.news.imgs = req.body.imgs
  delete bizParam.news.category
  delete bizParam.news.imgs
  console.log(bizParam)
  util.ajax('POST', api.SaveNews, req, bizParam, function (data, success) {
    callback && callback(data, success)
  })
}

exports.ChangeNewsState = function (req, callback) {
  var bizParam = {
    newsId: req.body.id,
    status: req.body.status
  }
  util.ajax('PUT', api.ChangeNewsState, req, bizParam, function (data, success) {
    callback && callback(data, success)
  })
}

exports.NewsDetailById = function (req, callback) {
  var bizParam = {
    newsId: req.query.id
  }
  console.log(bizParam)
  util.ajax('GET', api.ShowNewsDetail, req, bizParam, function (data, success) {
    callback && callback(data, success)
  })
}

exports.UpdateNews = function (req, callback) {
  var query = req.body
  var bizParam = {}
  bizParam.news = req.body
  bizParam.news.image = req.body.imgs
  bizParam.news.categoryId = req.body.category
  delete bizParam.news.updateAt
  delete bizParam.news.imgs
  delete bizParam.news.category
  console.log(bizParam)
  util.ajax('PUT', api.UpdateNews, req, bizParam, function (data, success) {
    callback && callback(data, success)
  })
}

exports.DeleteNews = function (req, callback) {
  var bizParam = {
    newsId: req.body.id
  }

  util.ajax('DELETE', api.DeleteNews, req, bizParam, function (data, success) {
    callback && callback(data, success)
  })
}
