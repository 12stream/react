// 治疗业务
var util = require('../lib/ajax');
var api = require('../lib/api');
var config = require('../config');
var qs = require('querystring')


exports.get_clinic_list = function (req, res, next) {
    var query = req.query;
    var currentPage = query.page || 1;
    var hospitalName = query.hospitalName || '';
    var telephone = query.telephone || '';
    var bizParam = {
        "pageSize": config.pageSize,
        "pageIndex": currentPage,
        "props": '{"hospitalName":"' + hospitalName + '","telephone":"' + telephone + '"}', //签名之前中文不能转码
        "sort": '',
        "order": '',
        "q": ''

    }
    util.ajax('GET', api.HospitalPage, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        req.json = json
        next();
        //callback && callback(json,success);
    });
}

exports.add_wx_dept = function (req, res, next) {
    var bizParam = {
        'addWxDepartmentRequest': req.body
    }
    util.ajax('POST', api.AddWxDept, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        req.json = json
        res.send(json);
    })
}

exports.edit_wx_dept = function (req, res, next) {
    var bizParam = {
        'updateWxDepartmentRequest': req.body
    }
    delete bizParam.hospitalId
    util.ajax('PUT', api.UpdateWxDept, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        req.json = json
        res.send(json);
    })
}

exports.get_wx_dept_list = function (req, res, next) {
    var bizParam = {
        'hospitalId': req.params.id.split('&')[0]
    }
    util.ajax('GET', api.GetWxDeptList, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        res.locals.wxDeptList = json.data;
        // req.json = json
        next();
    })
}

exports.get_doctor_list = function (req, res, next) {
    var currentPage = req.query.page || 1;
    var hospitalName = req.query.hospitalName || '';
    var telephone = req.query.telephone || '';
    var query = req.query;
    var bizParam = {
        "pageSize": config.pageSize,
        "pageIndex": currentPage,
        //"props": '{"hospitalName":"'+hospitalName+'","telephone":"'+telephone+'"}', //签名之前中文不能转码
        "props": {}, //签名之前中文不能转码
        // "sort":'',
        // "order":'',
        // "q":''
    }
    // console.log("query:",query)

    for (var key in query) {
        if (query[key]) {
            bizParam.props[key] = query[key]
        }
    }

    if (query.isRecommend) {
        // console.log("bizParam:",bizParam)
        bizParam.props.isRecommend = 'true';
        bizParam.props.isRecommend = (bizParam.props.isRecommend == query.isRecommend)
    }
    util.ajax('GET', api.DoctorPage, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        req.json = json
        next()
    });
};

exports.get_doctor_detail = function (req, res, next) {
    var id = req.params.id
    // console.log('id:',id)
    var bizParam = {
        "doctorId": id
    }
    util.ajax('GET', api.DoctorGet, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        //callback && callback(json,success);
        var hospitalId = '';
        var accountId = '';
        if (json.success) {
            hospitalId = json.data.hospitalReDepartments[0] ? json.data.hospitalReDepartments[0].hospitalId : '';
            accountId = json.data.accountId;
        }

        req.hospitalId = hospitalId;
        req.accountId = accountId;
        req.json = json;
        next()

    });

}
exports.get_account_detail = function (req, res, next) {
    var accountId = req.accountId
    console.log('accountId:', accountId)
    var bizParam = {
        "accountId": accountId
    }
    util.ajax('GET', api.AccountDetailGet, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        res.locals.get_account_detail = json;
        if (json.success) {
            res.locals.get_account_detail_success = json.success;
            res.locals.get_account_detail = json.data;
        }
        next()

    });

}
exports.update_doctor_detail = function (req, res, next) {
    var body = req.body

    console.log("body --------------------------》:",body)
    var doctorPhoto =JSON.parse(body.doctorPhoto)[0].imageUrl
    var bizParam = {
            "request": {
                rawRequest:{
                    id: body.id,
                    //doctorStatus: 1,
                    doctorPhoto: doctorPhoto,
                    doctorCode: body.doctorCode,
                    telephone: body.telephone,
                    cost: parseFloat((body.cost*100).toFixed(2)),
                    //accountId: '1002',
                    doctorName: body.doctorName,
                    titleId: body.doctorTitle,
                    introduction: body.introduction,
                    skill: body.skill,
                    type: body.type,
                    order:body.order,
                    hasActivity:body.activityOpen ==1?true:false,
                    activity:{
                        'price':parseFloat((body.cost*100).toFixed(2)),
                        'origPrice':parseFloat((body.originalPrice*100).toFixed(2)),
                        'name':body.identification
                    },
                    "hospitalReDepartments": [
                        {
                            "hospitalId": body.hospital,
                            "departmentId": body.department
                        }
                    ]
                }
            }
    }
    console.log("bizParam:", bizParam)
    util.ajax('PUT', api.DoctorUpdate, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        req.json = json
        next()

    });
}

exports.doctor_add = function (req, res, next) {
    var body = req.body
    // console.log('body:',body)
    // console.log('JSON.parse(body.doctorPhoto):',JSON.parse(body.doctorPhoto))
    var bizParam = {
        "request": {
            "rawRequest": {
                registerUser: {
                    account: body.telephone,
                    password: body.password
                },
                doctorDTO: {
                    doctorStatus: 1,
                    //doctorPhoto: body.doctorPhoto,
                    doctorPhoto: JSON.parse(body.doctorPhoto)[0].imageUrl,
                    doctorCode: '',
                    doctorName: body.doctorName,
                    titleId: body.titleId,
                    telephone: body.telephone,
                    cost: body.cost * 100,
                    introduction: body.introduction,
                    skill: body.skill,
                    "hospitalReDepartments": [{
                        "hospitalId": body.hospitalId,
                        "departmentId": body.departmentId
                    }]
                }

            }
        }

    }
    util.ajax('POST', api.DoctorAdd, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        // req.json = json;
        res.json(json)
        //next()
        //callback && callback(json,success);
    });
}

exports.change_doctorStatus = function (req, res, next) {
    var body = req.body;
    var bizParam = {
        "doctorId": body.doctorId,
        "doctorStatus": body.doctorStatus
    }

    util.ajax('put', api.DoctordoctorStatuschange, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        res.send(json);
        //callback && callback(json,success);
    });
}
exports.add_doctorRecommend = function (req, res, next) {
    var body = req.body;
    var bizParam = {
        "request": {
            "rawRequest": {
                "doctorId": body.doctorId,
                "recommendType": body.recommendType
            }
        }
    }

    util.ajax('post', api.Doctorrecommendadd, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        res.json(json)
    });
}

exports.delete_doctorRecommend = function (req, res, next) {
    var body = req.body;
    var bizParam = {
        "doctorId": body.doctorId,
        "recommendType": body.recommendType
    }

    util.ajax('delete', api.Doctorrecommendtypedelete, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        res.json(json)
    });
}


exports.add_doctorConsult = function (req, res, next) {
    var body = req.body;
    var bizParam = {
        "consult": {
            "doctorId": body.doctorId,
            "consultType": parseInt(body.consultType)
        }
    }

    util.ajax('post', api.Ddoctorconsultopen, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        res.json(json)
    });
}
exports.delete_doctorConsult = function (req, res, next) {
    var body = req.body;
    var bizParam = {
        "doctorId": body.doctorId,
        "consultType": parseInt(body.consultType)

    }

    util.ajax('delete', api.Doctorconsulttypeclose, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        res.json(json)
    });
}
exports.get_department_web = function (req, res, next) {
    var hospitalId = req.body.hospitalId;
    var bizParam = {
        "hospitalId": hospitalId
    }

    util.ajax('GET', api.DepartmentAll, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        //console.log("get_department:",json)
        res.json(json)
        //callback && callback(json,success);
    });
}

exports.charge_doctor = function (req, res, next) {
    var body = req.body
    var bizParam = {
        "request": {
            rawRequest: body
        }
    }
    console.log("bizParam:", bizParam)
    util.ajax('PUT', api.DoctorUpdate, req, bizParam, function (data, success) {
        res.send(data)

    });
}
exports.get_clinic_detail = function (req, res, next) {
    var id = req.params.id;
    id = id.split("&")[0];
    var bizParam = {
        "hospitalId": id
    };
    util.ajax('GET', api.HospitalGet, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        req.json = json;
        if (req.query.hospitalid) {
            res.send(json)
        } else {
            next();
        }

        //callback && callback(json,success);
    });
}
exports.add_clinic = function (req, res, next) {
    var body = req.body;
    var bizParam = {
        "hospitalDTO": body
    }
    util.ajax('post', api.HospitalAdd, req, bizParam, function (data, success) {
        res.send(data)
        // var json = JSON.parse(data);
        // req.json = json;
        // next()
        //callback && callback(json,success);
    });
}
exports.set_hospital_time = function (req, res, next) {
    var requestData = req.body
    var bizParam = requestData;
    util.ajax('POST', api.HospitalTimeSet, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        res.send(json)

    });
}

exports.set_dayis = function(req,res,next){
    var requestData = req.body
    var bizParam = requestData;
    util.ajax('POST',api.SetDayis,req, bizParam,function (data,success) {
        var json = JSON.parse(data);
        res.send(json)
    });
}


//添加上门取样的服务区域
exports.medical_serviceArea_add = function (req, res, next) {
    var item = req.body;
    var bizParam = {
        insertServiceAreaRequest: {
            city: item.city,
            district: item.district,
            hospitalId: item.hospitalId,
            type: item.type,
            province: item.province
        }
    }
    console.log(bizParam);
    util.ajax('POST', api.medicalServiceAreaAdd, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        res.send(json)
    });
}
//删除上门取样的服务区域
exports.serviceArea_batchDelete = function (req, res, next) {
    var data = req.body;
    var arr = [];
    data.deleteServiceAreaRequestList.forEach(function (item, index) {
        var obj = {
            areaId: item.areaId,
            level: item.level
        }
        arr.push(obj);
    })

    var bizParam = {
        hospitalId: data.hospitalId,
        type: data.type,
        deleteServiceAreaRequestList: arr
    };
    console.log(bizParam);
    util.ajax('delete', api.medicalServiceAreaBatchDelete, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        res.send(json)
    });
}


//获取门诊取样的时间表
exports.get_outpatient_time = function (req, res, next) {
    var query = req.query;
    var hospitalId = req.params.id;
    hospitalId = hospitalId.split("&")[0];
    console.log("门诊取样---------------------------------------门诊取样")
    var bizParam = {
        "hospitalId": hospitalId,
        "timeType": "2" //	类型：1营业时间 2门诊取样 3上门取样 4 快递取样
    }

    res.locals.outpatient = "2";
    util.ajax('get', api.HospitalTimeGetByType, req, bizParam, function (data, success) {
        var json = JSON.parse(data);

        var get_outpatient_time_success = res.locals.get_outpatient_time_success = json.success;
        if (get_outpatient_time_success) {
            res.locals.get_outpatient_time = json.data
        } else {
            res.locals.get_outpatient_time = json;
        }
        next();

        // if(!bSend){
        //     next()
        // }else{
        //     // res.send(json)
        //     var site_sampling_area = req.site_sampling_area;
        //     var express_sampling_area = req.express_sampling_area;
        //     res.render('treat/clinic_update_sampling_time',{
        //         site_sampling_area:site_sampling_area,
        //         express_sampling_area:express_sampling_area,
        //         data:json.data,
        //     },function(err, html) {
        //         if(err){
        //             console.log(err);
        //             res.send(err);
        //         }else{
        //             // console.log("html:",html)
        //             var data = {
        //                 success:json.success,
        //                 msg:json.msg,
        //                 html:html||''
        //             }
        //             res.send(data);
        //         }
        //     });
        // }

    });
}
//获取上门取样的时间表
exports.get_site_time = function (req, res, next) {
    var query = req.query;
    var hospitalId = req.params.id;
    hospitalId = hospitalId.split("&")[0];
    console.log("上门取样---------------------------------------上门取样")
    var bizParam = {
        "hospitalId": hospitalId,
        "timeType": "3" //	类型：1营业时间 2门诊取样 3上门取样 4 快递取样
    }

    res.locals.site = "3";
    util.ajax('get', api.HospitalTimeGetByType, req, bizParam, function (data, success) {
        var json = JSON.parse(data);

        var get_site_time_success = res.locals.get_site_time_success = json.success;
        if (get_site_time_success) {
            res.locals.get_site_time = json.data
        } else {
            res.locals.get_site_time = json
        }
        next();

        // if(!bSend){
        //     next()
        // }else{
        //     // res.send(json)
        //     var site_sampling_area = req.site_sampling_area;
        //     var express_sampling_area = req.express_sampling_area;
        //     res.render('treat/clinic_update_sampling_time',{
        //         site_sampling_area:site_sampling_area,
        //         express_sampling_area:express_sampling_area,
        //         data:json.data,
        //     },function(err, html) {
        //         if(err){
        //             console.log(err);
        //             res.send(err);
        //         }else{
        //             // console.log("html:",html)
        //             var data = {
        //                 success:json.success,
        //                 msg:json.msg,
        //                 html:html||''
        //             }
        //             res.send(data);
        //         }
        //     });
        // }

    });
}
//获取营业时间
exports.get_hospital_time = function (req, res, next) {
    var query = req.query;
    var hospitalId = req.params.id;
    hospitalId = hospitalId.split("&")[0];
    console.log("营业时间---------------------------------------营业时间")
    var bizParam = {
        "hospitalId": hospitalId,
        "timeType": "1" //	类型：1营业时间 2门诊取样 3上门取样 4 快递取样
    }

    res.locals.hospital = "1";
    util.ajax('get', api.HospitalTimeGetByType, req, bizParam, function (data, success) {
        var json = JSON.parse(data);

        var get_hospital_time_success = res.locals.get_hospital_time_success = json.success;
        if (get_hospital_time_success) {
            res.locals.get_hospital_time = json.data
        } else {
            res.locals.get_hospital_time = json
        }
        next();

        // if(!bSend){
        //     next()
        // }else{
        //     // res.send(json)
        //     var site_sampling_area = req.site_sampling_area;
        //     var express_sampling_area = req.express_sampling_area;
        //     res.render('treat/clinic_update_sampling_time',{
        //         site_sampling_area:site_sampling_area,
        //         express_sampling_area:express_sampling_area,
        //         data:json.data,
        //     },function(err, html) {
        //         if(err){
        //             console.log(err);
        //             res.send(err);
        //         }else{
        //             // console.log("html:",html)
        //             var data = {
        //                 success:json.success,
        //                 msg:json.msg,
        //                 html:html||''
        //             }
        //             res.send(data);
        //         }
        //     });
        // }

    });
}
//获取快递取样的时间
exports.get_express_time = function (req, res, next) {
    var query = req.query;
    var hospitalId = req.params.id;
    hospitalId = hospitalId.split("&")[0];
    console.log("快递取样---------------------------------------快递取样")
    var bizParam = {
        "hospitalId": hospitalId,
        "timeType": "4" //	类型：1营业时间 2门诊取样 3上门取样 4 快递取样
    }

    res.locals.express = "4";
    util.ajax('get', api.HospitalTimeGetByType, req, bizParam, function (data, success) {
        var json = JSON.parse(data);

        var get_express_time_success = res.locals.get_express_time_success = json.success;
        if (get_express_time_success) {
            res.locals.get_express_time = json.data
        }
        next();

        // if(!bSend){
        //     next()
        // }else{
        //     // res.send(json)
        //     var site_sampling_area = req.site_sampling_area;
        //     var express_sampling_area = req.express_sampling_area;
        //     res.render('treat/clinic_update_sampling_time',{
        //         site_sampling_area:site_sampling_area,
        //         express_sampling_area:express_sampling_area,
        //         data:json.data,
        //     },function(err, html) {
        //         if(err){
        //             console.log(err);
        //             res.send(err);
        //         }else{
        //             // console.log("html:",html)
        //             var data = {
        //                 success:json.success,
        //                 msg:json.msg,
        //                 html:html||''
        //             }
        //             res.send(data);
        //         }
        //     });
        // }

    });
}
//获取上门取样的服务区域
exports.get_hospital_serviceArea = function (req, res, next) {
    var id = req.params.id;
    id = id.split("&")[0];
    var bizParam = {
        "hospitalId": id,
        "type": "3"
    };
    util.ajax('GET', api.HospitalServiceArea, req, bizParam, function (data, success) {
        //获取上门取样的服务区域
        var json = JSON.parse(data);
        res.locals.site_sampling_area_success = json.success;
        if (json.success) {
            var data = json.data;
            //定义我想要的数组来接收数据
            var wantArr = [];
            //开始循环数据
            for (var i = 0; i < data.length; i++) {
                // level1 的临时变量
                var temp = {};
                temp.name = data[i].area;
                temp.level = data[i].level;
                temp.areaId = data[i].areaId;
                wantArr.push(temp);
                //定义一个临时的变量来接收当前对象的第二级
                var two = data[i].children;
                for (var j = 0; j < two.length; j++) {
                    // level2 的临时变量
                    var obj = {};
                    obj.name = two[j].area;
                    obj.level = two[j].level;
                    obj.areaId = two[j].areaId;
                    obj.offset = data[i].area;
                    obj.offsetId = data[i].areaId;
                    wantArr.push(obj);
                    //定义一个临时的变量来接收当前对象的第三级
                    var three = two[j].children;
                    for (var k = 0; k < three.length; k++) {
                        // level2 的临时变量
                        var tempobj = {};
                        tempobj.name = three[k].area;
                        tempobj.level = three[k].level;
                        tempobj.areaId = three[k].areaId;
                        tempobj.offset = data[i].area;
                        tempobj.offsetId = data[i].areaId;
                        tempobj.of = two[j].area;
                        tempobj.ofId = two[j].areaId;
                        wantArr.push(tempobj);
                    }
                }
            }

            console.log("3333333333333333333333333333333333333333333333333333333333333333333333333");
            //数据拼装完成
            console.log(wantArr);
            console.log("3333333333333333333333333333333333333333333333333333333333333333333333333");

            res.locals.site_sampling_area = wantArr;
        }
        next();
    });
}
//获取快递取样的服务区域
exports.get_hospital_serviceArea1 = function (req, res, next) {
    var id = req.params.id;
    id = id.split("&")[0];
    var bizParam = {
        "hospitalId": id,
        "type": "4"
    };
    util.ajax('GET', api.HospitalServiceArea, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        res.locals.express_sampling_area_success = json.success;
        if (json.success) {
            var data = json.data;
            //定义我想要的数组来接收数据
            var wantArr = [];
            //开始循环数据
            for (var i = 0; i < data.length; i++) {
                // level1 的临时变量
                var temp = {};
                temp.name = data[i].area;
                temp.level = data[i].level;
                temp.areaId = data[i].areaId;
                wantArr.push(temp);
                //定义一个临时的变量来接收当前对象的第二级
                var two = data[i].children;
                for (var j = 0; j < two.length; j++) {
                    // level2 的临时变量
                    var obj = {};
                    obj.name = two[j].area;
                    obj.level = two[j].level;
                    obj.areaId = two[j].areaId;
                    obj.offset = data[i].area;
                    wantArr.push(obj);
                }
            }
            console.log("4444444444444444444444444444444444444444444444444444444444444444444444444444");
            //数据拼装完成
            console.log(wantArr);
            console.log("4444444444444444444444444444444444444444444444444444444444444444444444444444");
            res.locals.express_sampling_area = wantArr;
            // req.express_sampling_area = wantArr;
        }
        next();
    });
}

exports.get_dayis = function(req,res,next){
    var id = req.params.id;
    id = id.split("&")[0];
    console.log('11111111111111111111111111111111111111');
    var bizParam = {
        "outpatientId": id,
    };
    util.ajax('GET',api.GetDayis,req, bizParam,function (data,success) {
        var json = JSON.parse(data);
        var getDayis = json.data;
        console.log(getDayis);
        if(json.success){
            res.locals.getDayis = getDayis;
        }
        next();
    });
}

exports.updata_clinic_detail = function(req,res,next){
    var requestData = req.body
    //console.log('requestData:',requestData)
    var bizParam = {
        "request": {
            "rawRequest": requestData
        }

    }
    // var bizParam = {
    //     "request":{
    //         "rawRequest":{
    //             "id": requestData.id,
    //             "address": requestData.address,
    //             "description": requestData.description,
    //             "telephone": requestData.telephone
    //         }
    //     }
    //
    // }
    util.ajax('PUT', api.HospitalUpdate, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        req.json = json;
        next()
        //callback && callback(json,success);
    });
}
exports.updata_clinic_statue = function (req, res, next) {
    var requestData = req.body
    //console.log('requestData:',requestData)
    var bizParam = {
        "hospitalId": requestData.id,
        "operatingState": requestData.operatingState
    }
    util.ajax('PUT', api.HospitalOperatingStateUpdate, req, bizParam, function (data, success) {
        var json = data
        req.json = json
        next()
        //callback && callback(json,success);
    })
}


exports.get_register_list = function (req, res, next) {
    var query = req.query;
    var currentPage = query.page || 1;
    var status = req.params.status || 1;
    res.locals.status = status;
    var bizParam = {
        role: 2,
        command: {
            "pageSize": config.pageSize,
            "pageIndex": currentPage,
            "status": status
        }

    }

    for (var key in query) {
        if (query[key]) {
            bizParam.command[key] = query[key]

        }
    }
    console.log("api.ReservationPage:", api.ReservationPage)
    util.ajax('GET', api.ReservationPage, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        req.json = json
        next();

    });
}
exports.get_register_detail = function (req, res, next) {
    var reservationId = req.params.reservationId;
    var bizParam = {
        "reservationId": reservationId,
        "role": 2
    };
    util.ajax('get', api.ReservationGetByid, req, bizParam, function (data, success) {
        var json = JSON.parse(data);
        req.json = json;
        next()
    });
}
exports.add_remark = function (req, res, next) {
    var body = req.body;
    var bizParam = body;
    util.ajax('PUT', api.ReservationRemarkAdd, req, bizParam, function (data, success) {
        res.send(data)
    })
}
exports.refund_register = function (req, res, next) {
    var body = req.body;
    var bizParam = body;
    util.ajax('PUT', api.ReservationRefund, req, bizParam, function (data, success) {
        res.send(data)
    })
}

exports.add_register = function (req, res, next) {
    var body = req.body;
    var bizParam = body;
    util.ajax('PUT', api.ReservationCheck, req, bizParam, function (data, success) {
        res.send(data)
    })
}