var http = require('http');
var config = require('../../config');
var md5 = require("blueimp-md5");
var qs = require('querystring');
//获取数据
exports.ajaxSign = function(obj){
    var method = obj.type.toUpperCase();
    var data = "bizParam="+JSON.stringify(obj.bizParam)+"&sysParam="+JSON.stringify(obj.sysParam);
    console.log('===='+method+'==='+data);
    if(method == 'PUT' || method == 'POST'){
        var options = {
            hostname: config.hostname_test,
            port: config.port_test,
            path: config.path,
            method: obj.type,
            headers:{
                'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
            }
        };
         console.log(options)
        var allData = '';
        var request = http.request(options, function (response) {
            console.log('=====response');
            response.on('data', function (json) {
                allData += json;
            });
            response.on('end', function() {
                console.log('BODY: ' + allData);
                obj.success&&obj.success(allData);
                console.log('==='+obj.success+'==='+obj.sendJson);
                obj.sendJson&&obj.res.json(allData);
            })
        });
        request.on('error', function (e) {
            console.log('problem with request: ' + e);
        });
        request.write(data);
        request.end();
    }else if(method == 'DELETE'){
        var request = require("request");
        console.log(request);
        var uri = "http://"+config.hostname_test+":"+config.port_test+config.path;
        console.log(uri);
        request({
            uri:uri,
            method: "DELETE",
            form: {
                bizParam:JSON.stringify(obj.bizParam),
                sysParam:JSON.stringify(obj.sysParam)
            }
        }, function(error, response, body) {
            console.log('BODY: '+body);
            obj.success&&obj.success(body);
            console.log('==='+obj.success+'==='+obj.sendJson);
            obj.sendJson&&obj.res.json(body);
        });

    }else{
        var options = {
            hostname: config.hostname_test,
            port: config.port_test,
            path: config.path+'?'+data,
            method: obj.type||'GET'
        };
        console.log(options)
        var allData = '';
        var request = http.request(options, function (response) {
            response.on('data', function (json) {
                allData += json;
            });
            response.on('end', function() {
                console.log('BODY: ' + allData);
                obj.success&&obj.success(allData);
                obj.sendJson&&obj.res.json(allData);
            });
        });
        request.on('error', function (e) {
            console.log('problem with request: ' + e);
        });
        request.end();
    } 
}


exports.tbSign = function (obj) {
    // 时间戳
    var time = new Date();
    var timestamp = time.getTime()
    obj.timestamp = timestamp;

    // 程序key
    obj.appKey = config.appKey;
    obj.v = config.v;
    obj.format = config.format;


    var arr = [];
    for(var p in obj){
        arr.push(p + obj[p]);
    }
    arr.sort();

    // 参数喘
    var msg =  arr.join('');
    //console.log("msg:",msg);
    var msg = config.secret+msg+config.secret;
    console.log("msg2:",msg);
    // Hmac 签名
    //var sign = md5(msg, config.secret);
    var sign = md5(msg);

    var sysParam = {
        "sign":sign,
        "timestamp":timestamp,
        "v":config.v,
        "format":config.format,
        "appKey":config.appKey,
        "apiName":obj.apiName,
        "session":obj.session
    };
    // 返回
    return sysParam;
}
exports.ajax = function(obj){
    var bizParam=obj.data;
    var options = {
        hostname: config.hostname,
        port: config.port,
        //path: '/goods/state/update.do?bizParam='+JSON.stringify(bizParam),
        path: obj.url+'?bizParam='+JSON.stringify(bizParam),
        method: obj.type||'GET'
    };
    if(obj.type =='POST'||obj.type=='post'){
        options.headers = {
           // 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
        }
    }
    console.log(options)
    var allData = '';
    var request = http.request(options, function (response) {
        response.on('data', function (json) {
            allData += json;
        });
        response.on('end', function() {
            console.log('BODY: ' + allData);
            //res.json(allData)
            if(!obj.sendJson){
                obj.res.json(allData)
            }
            obj.success(allData)
            //obj.res.json(allData)

        })
    });
    request.on('error', function (e) {
        console.log('problem with request: ' + e);
    });
    request.end();
}
exports.extend = function() {
    var src, copyIsArray, copy, name, options, clone,
        target = arguments[0] || {},
        i = 1,
        length = arguments.length,
        deep = false;
    // Handle a deep copy situation
    if ( typeof target === "boolean" ) {
        deep = target;
        // skip the boolean and the target
        target = arguments[ i ] || {};
        i++;
    }
    // Handle case when target is a string or something (possible in deep copy)
    if ( typeof target !== "object" && !jQuery.isFunction(target) ) {
        target = {};
    }
    // extend jQuery itself if only one argument is passed
    if ( i === length ) {
        target = this;
        i--;
    }
    for ( ; i < length; i++ ) {
        // Only deal with non-null/undefined values
        if ( (options = arguments[ i ]) != null ) {
            // Extend the base object
            for ( name in options ) {
                src = target[ name ];
                copy = options[ name ];
                // Prevent never-ending loop
                if ( target === copy ) {
                    continue;
                }
                target[ name ] = copy;
            }
        }
    }
    // Return the modified object
    console.log('target:',target)
    return target;
};
exports.tryCatch= function(err,req,res,next){
    try{
        next()
    }catch(err){
        console.log('错误：',err)
    }
}