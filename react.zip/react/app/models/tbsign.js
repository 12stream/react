//var md5 = require('blueimp-md5').md5;
var config = require('../../config')
var md5 = require("blueimp-md5")
var tbSign = function (obj) {
    // 时间戳
    var time = new Date();
    var timestamp = time.getTime()
    obj.timestamp = timestamp;

    // 程序key
    obj.appKey = config.appKey;
    obj.v = config.v;
    obj.format = config.format;

    // 参数数组
    var arr = [];
    // 循环添加参数项
    for(var p in obj){
        arr.push(p + obj[p]);
    }
    // 排序
    arr.sort();
    //console.log('arr:',arr)
    // 参数喘
    var msg =  arr.join('');
    console.log("msg:",msg);
    var msg = config.secret+msg+config.secret;

    console.log("msg2:",msg);
    // Hmac 签名
    //var sign = md5(msg, config.secret);
    var sign = md5(msg);

    var sysParam = {
        "sign":sign,
        "timestamp":timestamp,
        "v":config.v,
        "format":config.format,
        "appKey":config.appKey,
        "apiName":obj.apiName
    };
    // 返回
    return sysParam;
}

module.exports.tbSign = tbSign;