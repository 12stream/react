/*
* 科普模块  kepu
* */
var http = require('http');
var express = require('express');
var url = require('url');
var qs = require('querystring');
var path = require('path');
var app = express();
var config = require('../../config');
var utils = require('../models/utils');
var staticize = require('../models/staticize');




exports.detail = function(req,res){
    //接收页面传过来的数据
    var query = req.query;
    console.log('----id--'+query.id);
    var bizParam={
        "id": query.id
    }

    var obj={
        "apiName":"cms.article.selectArticleById",
        "session":"1"
    };

    utils.extend(obj,bizParam);
    var sysParam = utils.tbSign(obj);

    utils.ajaxSign({
        bizParam:bizParam,
        sysParam:sysParam,
        type:'GET',
        res:res,
        success:function(data){
            var json = JSON.parse(data);
            if(json.success){
                res.render('kepu/detail',{
                    title:'健康科普_文章详情页',
                    data:json.data
                });

            }else{
                res.json(json.msg);
            }
        }
    });

}

exports.modifyView = function(req,res){
    console.log('-----id--'+req.query.id);
    var bizParam={
        "id": req.query.id
    }

    var obj={
        "apiName":"cms.article.selectArticleById",
        "session":"1"
    };

    utils.extend(obj,bizParam);
    var sysParam = utils.tbSign(obj);

    utils.ajaxSign({
        bizParam:bizParam,
        sysParam:sysParam,
        type:'GET',
        res:res,
        success:function(data){
            var json = JSON.parse(data);
            if(json.success){
                res.render('kepu/modify',{
                    title:'健康科普_文章修改',
                    data:json.data
                });
            }else{
                res.json(json.msg);
            }
        }
    });
}


exports.modify = function(req,res){
    console.log('new');
    //接收页面传过来的数据
    var query = req.query;
    if(query.categorys){query.categorys = [1]};
    if(query.imgs){query.imgs = JSON.parse(query.imgs)};
    
    delete query.editorValue;
    console.log('======='+query.content);

    var bizParam = {"dto":query};

    var obj={
        "apiName":"cms.article.changeArticle",
        "session":"1",
        "dto":JSON.stringify(query)
    };

    var sysParam = utils.tbSign(obj);

    if(query.title){query.title = encodeURI(query.title);}
    if(query.author){query.author = encodeURI(query.author);}
    if(query.source){query.source = encodeURI(query.source);}
    if(query.keyword){query.keyword = encodeURI(query.keyword);}
    if(query.wapDesc){query.wapDesc = encodeURI(query.wapDesc);}
    if(query.brief){query.brief = encodeURI(query.brief);}
    if(query.content){query.content = encodeURI(query.content.replace(/"/g, '\\\"'));}

    console.log('======='+query.content);

    utils.ajaxSign({
        bizParam:bizParam,
        sysParam:sysParam,
        type:'POST',
        res:res,
        success: function (data) {
            var json = JSON.parse(data);
            getHtmlAndModUrl(json,res);
        }
    });
}


exports.add = function(req,res){
    res.render('kepu/add',{
        title:'健康科普_新增文章',
        content:'健康常识页面内容'
    })
}

exports.new = function(req,res){
    console.log('new');
    //接收页面传过来的数据
    var query = req.query;
    query.categorys = [1];
    query.imgs = JSON.parse(query.imgs);
    
    delete query.editorValue;
    console.log('======='+query.content);

    var bizParam = {"dto":query};

    var obj={
        "apiName":"cms.article.createArticle",
        "session":"1",
        "dto":JSON.stringify(query)
    };

    var sysParam = utils.tbSign(obj);

    if(query.title){query.title = encodeURI(query.title);}
    if(query.author){query.author = encodeURI(query.author);}
    if(query.source){query.source = encodeURI(query.source);}
    if(query.keyword){query.keyword = encodeURI(query.keyword);}
    if(query.wapDesc){query.wapDesc = encodeURI(query.wapDesc);}
    if(query.brief){query.brief = encodeURI(query.brief);}
    if(query.content){query.content = encodeURI(query.content.replace(/"/g, '\\\"'));}


    utils.ajaxSign({
        bizParam: bizParam,
        sysParam: sysParam,
        type: 'POST',
        res: res,
        success: function (data) {
            var json = JSON.parse(data);
            getHtmlAndModUrl(json,res);
        }
    });
}

exports.search = function(req,res){
    console.log('search');
    
    var query = req.query;
    var currentPage = query.page||1;
    console.log('======='+JSON.stringify(query));
    
    var bizParam={
        "pageIndex": currentPage,
        "pageSize": 5,
        "category":query.category,
        "tc":query.tc || ''
    };
    
    var obj={
        "apiName":"cms.article.pageQueryArticleByTitleOrContentAndCat",
        "session":"1"
    };

    utils.extend(obj,bizParam);
    var sysParam = utils.tbSign(obj);

    if(bizParam.tc){bizParam.tc = encodeURI(bizParam.tc);}

    utils.ajaxSign({
        bizParam:bizParam,
        sysParam:sysParam,
        type:'GET',
        res:res,
        success:function(data){
            console.log('===='+data);
            var json = JSON.parse(data);
            if(json.success){
                res.locals.pagecount=json.data.pageCount;
                res.locals.currentpage = currentPage;

                delete query.page;
                var queryStr = '';
                for(var attr in query){
                    queryStr += attr + '=' + query[attr] + '&';
                }

                res.locals.query = queryStr;
                res.locals.category = query.category || '1';
                res.locals.tc = query.tc || '';
                res.render('kepu/list',{
                    title:'健康科普_文章列表',
                    data:json.data.data
                });
            }else{
                res.json(json.msg);
            }
            
        }
    });
}


exports.del = function(req,res){
    //接收页面传过来的数据
    var bizParam={
        "id": req.query.id
    }

    var obj={
        "apiName":"cms.article.terminateArticle",
        "session":"1"
    };

    utils.extend(obj,bizParam);
    var sysParam = utils.tbSign(obj);

    utils.ajaxSign({
        bizParam:bizParam,
        sysParam:sysParam,
        type:'DELETE',
        res:res,
        sendJson:true
    });
}

//得到静态文件并修改URL
function getHtmlAndModUrl(json,res){
    var htmlPath = 'http://' + config.hostname_node + ':' + config.port_node + '/htmls/article' + json.data.id + '.html';//静态HTML地址
    console.log('===='+htmlPath);
    staticize.staticize(path.resolve(__dirname, '../views/kepu/detailHtml.jade'), json, path.resolve(__dirname, '../../public/htmls/article' + json.data.id + '.html'), function () {
        var query = {url:htmlPath,id:json.data.id};
        var bizParam = {"dto":query};

        var obj={
            "apiName":"cms.article.changeArticle",
            "session":"1",
            "dto":JSON.stringify(query)
        };

        var sysParam = utils.tbSign(obj);

        utils.ajaxSign({
            bizParam:bizParam,
            sysParam:sysParam,
            type:'POST',
            res:res,
            success:function(data){
                //把id传回页面,用来查询详情
                var data = JSON.parse(data);
                data.data = {};
                data.data.id = json.data.id;
                res.json(JSON.stringify(data));

            }
        });

    });
}


