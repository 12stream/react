define(function (require, exports, module) {
  function updateImages(file) {
    function createCORSRequest(method, url) {
      let xhr = new XMLHttpRequest()
      if ('withCredentials' in xhr) {
        // "withCredentials"属性是X2中独有的
        xhr.open(method, url, true)
      } else if (typeof XDomainRequest !== 'undefined') {
        // IE
        xhr.open(method, url)
      } else {
        xhr = null
      }
      xhr.onerror = () => message.error('上传失败', 2)
      return xhr
    }

    return new Promise(function (resolve) {
      $.ajax({
        url: '/api/file.webToken',
        data: {
          encode: JSON.stringify({
            command: {
              rawRequest: {
                fileType: 1,
                appId: 'DAQ-WebPage',
                fileName: file.name,
                businessId: '22001',
              },
            }
          })
        },
        success: function (result) {
          const url = result.data.host
          const xhr = createCORSRequest('POST', url)
          const formdata = new FormData()
          const p = result.data.params
          formdata.append('name', p['x:title'])
          formdata.append('key', result.data.objectKey)
          formdata.append('policy', result.data.policy)
          formdata.append('OSSAccessKeyId', result.data.accessId)
          formdata.append('success_action_status', 200)
          formdata.append('callBack', result.data.callBack)
          formdata.append('signature', result.data.signature)
          formdata.append('x:filetype', p['x:filetype'])
          formdata.append('x:directoryid', p['x:directoryid'])
          formdata.append('x:bucketid', p['x:bucketid'])
          formdata.append('x:appid', p['x:appid'])
          formdata.append('x:title', p['x:title'])
          formdata.append('file', file)
          xhr.onreadystatechange = () => {
            if (xhr.readyState === 4) {
              if (xhr.status >= 200) {
                const { data } = JSON.parse(xhr.response)
                resolve(data)
              }
            }
          }
          xhr.send(formdata)
        }
      })
    })

  }
  module.exports = {
    updateImages,
  }
})
