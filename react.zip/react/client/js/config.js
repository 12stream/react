define(function(require,exports,module) {
    module.exports = {
        host: 'localhost',
        port: 8080, //端口
        hostname: 'http://120.76.24.129',
        appKey: 'T-OPF-02191317',  //授权AppKey
        secret:'themis-opf-test', //密匙
        "v":"1.0.0",
        "format":"json"
    }
})