//公共
define(function(require,exports,module) {
    require('jquery')
    $(function(){
        require('./common')
    })

})
