/**
 * Created by Administrator on 2017/5/12 0012.
 */

/**
 * Created by Administrator on 2017/5/11 0011.
 */
define(function(require,exports,module) {
    var utils = require('../utils');
    var moment = require("moment")
    var daterangepicker = require("daterangepicker");
    var moment = window.moment;

    var condition = {};

    var len = $('#content').data('length');
    if(!len){
        $('.outputfile input:button').attr('disabled',true)
    }else{
        $('.outputfile input:button').attr('disabled',false)
    }


    $('.startDate').daterangepicker({
        'autoUpdateInput':true,
        'singleDatePicker':true,
        "showDropdowns": true,
        'maxDate' : moment(),
        "dateLimit": {
            "days": 6
        },
        locale : {
            format : 'YYYY-MM-DD',
            daysOfWeek : [ '日', '一', '二', '三', '四', '五', '六' ],
            monthNames : [ '一月', '二月', '三月', '四月', '五月', '六月',
                '七月', '八月', '九月', '十月', '十一月', '十二月' ]
        }
    }, function (start, end) {
        condition.dateStart = start.format('YYYY-MM-DD');
        $('.startDate').val(start.unix());
    });

    $('.endDate').daterangepicker({
        'autoUpdateInput':true,
        'singleDatePicker':true,
        "showDropdowns": true,
        'maxDate' : moment(),
        "dateLimit": {
            "days": 30
        },
        locale : {
            format : 'YYYY-MM-DD',
            daysOfWeek : [ '日', '一', '二', '三', '四', '五', '六' ],
            monthNames : [ '一月', '二月', '三月', '四月', '五月', '六月',
                '七月', '八月', '九月', '十月', '十一月', '十二月' ]
        }
    }, function (start, end) {
        condition.dateEnd = start.format('YYYY-MM-DD');
        $('.endDate').val(start.unix())
    });

    $('#toSearch').on('click',function(){
        // alert(condition.dateStart);
        // alert(condition.dateEnd);

        condition.hospitalId = $('#selectHospital option:selected').val();
        condition.orgType = $('#selectorgType option:selected').val();
        condition.payWay = $('#selectpayType option:selected').val();

        var a = $('.startDate').val();
        var b = $('.endDate').val();

        // alert(a);
        // alert(b);

        var starts = new Date(a).getTime();
        var end = new Date(b).getTime();

        if(starts && end){
            if(end < starts){
                var prox = new utils.MsgShow({
                    delayTime: 3000,
                    title: '结束时间应该大于开始时间'
                }).hideMsg()
                return;
            }
        }

        //关于搜索的起始时间，用户开始时间和结束时间都没有选择的话，那就传空过去，如果用户只选择一个时间，另外一个时间传默认值。如果两个时间都修改了，那就一起传过去

        // console.log(condition);
        // alert(condition.dateStart||a);
        // alert(condition.dateEnd||b);

        $("input[name=payWay]").val(condition.payWay||'')
        $("input[name=orgType]").val(condition.orgType||'')
        $("input[name=hospitalId]").val(condition.hospitalId||'')
        $("input[name=dateEnd]").val(condition.dateEnd||b)
        $("input[name=dateStart]").val(condition.dateStart||a)
        $('#wantToSubmit').submit();
    })

    $('.outputfile input').on('click',function(){
        //  根据搜索条件导出excel
        location.href = '/finance/outputBooksExcel'
    })

});