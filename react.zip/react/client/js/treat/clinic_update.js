'use strict';
define(function(require,exports,module) {
    var utils = require('../utils');
    require('./city');
    require('./wx-deptm');

    $(function () {
        var $body = $('body');
        var hospitalId = $('.hospitalId').val();
        utils.tab('.tabBox .hd','.tabBox .con');
        $body.on('click','.tabBox .hd .needclick',function () {
            

            // var $self =$(this) ;
            // //获取当前点击span标签的索引
            // var index = $(this).index();
            // var timeType = this.getAttribute('data-timeType');
            // //获取对应的ul标签
            // var $ul = $('.tabBox .con ul').eq(index);
            // // console.log("index:",index,$(this))
            // var data = {
            //     bSend:true,
            //     timeType:timeType,
            //     hospitalId:hospitalId
            // };
            // console.log(data);
            // if(!$self.hasClass('success')&&index>0){
            //     $.ajax({
            //         type:'get',
            //         data:data,
            //         url:'/treats/clinic/get_hospital_time',
            //         beforeSend:function(){
            //             // console.log("正在获取数据")
            //             $ul.html('正在获取数据……')
            //         },
            //         success:function(json){
            //             console.log("json:",json)
            //             $self.addClass('success');
            //             if(json.success){
            //                 $ul.html(json.html)
            //             }else{
            //                 new utils.MsgShow({
            //                     title:json.msg
            //                 }).hideMsg()
            //             }
            //
            //
            //
            //         }
            //
            //     })
            // }

        })
        $body.on('click','.updateBtn,.saveBtn',function () {
            var $self = $(this);
            var $inputs = $self.parents('ul').find('input');
            var index = $self.parents('.tabBox').find('.hd span.on').index();
            var timeType = $self.parents('.tabBox').find('.hd span.on').attr('data-timeType');
            // console.log("index:",index,"timeType:",timeType);
            // console.log("$self：",$self,$(this).hasClass("updateBtn"),$inputs)
            if($self.hasClass('updateBtn')){
                $self.addClass('saveBtn').removeClass('updateBtn').html('保存');
                $inputs&&$inputs.map(function (index,item) {
                    $(item).attr('disabled',false)
                })
            }else {
              //获取所有的input标签
                var $selfUl = $self.parents('ul'),
                    intervals = $selfUl.find('.intervals').val()||'0',
                    limitCount = $selfUl.find('.limitCount').val(),
                    startTimeH = $selfUl.find('.startTimeH').val(),
                    startTimeM = $selfUl.find('.startTimeM').val(),
                    endTimeH = $selfUl.find('.endTimeH').val(),
                    endTimeM = $selfUl.find('.endTimeM').val(),
                    daiys = $selfUl.find('.daiys').val(),
                    timiys = $selfUl.find('.timiys').val(),
                    startTime = startTimeH+':'+startTimeM+':00',
                    endTime = endTimeH+':'+endTimeM+':00';


                // console.log("startTimeH:",startTimeH,"startTimeM:",startTimeM,parseInt(startTimeH))
                console.log("可预约的人数是：----------"+limitCount);

                if(typeof limitCount =='number' && parseInt(limitCount)>0){
                  new utils.MsgShow({
                    title:'可预约的人数必须大于0且为整数'
                  }).hideMsg()
                  return
                }

                if(timeType=="1"){
                    limitCount = 0;
                }

                var reg_hm = /^(0\d{1}|1\d{1}|2[0-3]):([0-5]\d{1}):(00)$/;
                if(!reg_hm.test(startTime)){
                    new utils.MsgShow({
                        title:'起始时间格式不正确'
                    }).hideMsg()
                    return
                }
                if(!reg_hm.test(endTime)){
                    new utils.MsgShow({
                        title:'结束时间格式不正确'
                    }).hideMsg()
                    return
                }


                if(startTime.split(':').join('')>=endTime.split(':').join('')){
                    new utils.MsgShow({
                        title:'结束时间必须大于起始时间'
                    }).hideMsg()
                    return
                }
                if(timeType!=1){
                    if(parseFloat(intervals)<=0||parseFloat(intervals)%1!=0||isNaN(intervals)){
                        new utils.MsgShow({
                            title:'间隔时间必须大于零的整数'
                        }).hideMsg()
                        return
                    }

                }
                var hourDiff = endTimeH-startTimeH,
                    minuteDiff = endTimeM-startTimeM,
                    timeDiff = hourDiff*60+minuteDiff;
                if(timeDiff<intervals){
                    new utils.MsgShow({
                        title:'起始和结束的时间差必需大于时间间隔'
                    }).hideMsg()
                    return
                }
                var integerTime = timeDiff%intervals;
                if(integerTime){
                    new utils.MsgShow({
                        title:'结束时间不正确，时间差距应该为时间间隔的倍数'
                    }).hideMsg()
                    return
                }
                var $weeks = $selfUl.find('.week:checked');
                var weeks = [];

                $.each($weeks,function(index,item){
                    weeks.push($(item).val())
                });
                    // console.log("weeks:",weeks);


                var data = {
                    "insertHospitalTimeRequests": [
                        // {
                        //     "hospitalId": "123",
                        //     "timeType": 1,
                        //     "startTime": "08:00",
                        //     "endTime": "17:30",
                        //     "intervals": 30,
                        //     "week": 1
                        // }
                    ]
                }

                if(weeks.length){
                    for(var value in weeks)
                        data.insertHospitalTimeRequests.push({
                            hospitalId:hospitalId,
                            timeType:timeType,
                            startTime:startTime,
                            endTime:endTime,
                            capacity:limitCount,
                            intervals:intervals,
                            week:weeks[value],
                            scheduleDays:daiys,
                            leadTime:timiys
                        })
                }
              // console.log("data:",data)
                var popop = new utils.Popup({
                    msg:'<h2>时间编辑提示</h2><p>保存后时间会被修改</p>',
                    bCancel:true,
                    okText:'保存',
                    isHide:false,
                    okCallback:function (){
                        $.ajax({
                            type:'POST',
                            data:data,
                            url:'/treats/clinic/set_hospital_time',
                            success:function(json){
                                // console.log("json:",json)
                                if(json.success){
                                    new utils.MsgShow({
                                        title:'保存成功'
                                    }).hideMsg()
                                    popop.hideBox(function () {
                                        $inputs&&$inputs.map(function (index,item) {
                                            $(item).attr('disabled',true)
                                        });
                                        $self.addClass('updateBtn').removeClass('saveBtn').html('编辑')
                                    })
                                }else{
                                    new utils.MsgShow({
                                        title:json.msg
                                    }).hideMsg()
                                    popop.hideBox()
                                }
                            }
                        })
                    }
                })

            }
        })
        // 门诊挂号放号设置
        $body.on('click','.fanghao .updateBtn1,.saveBtn1',function () {

            var $self = $(this);
            var $inputs = $self.parents('ul').find('input');
            if($self.hasClass('updateBtn1')){
                $self.addClass('saveBtn1').removeClass('updateBtn1').html('保存');
                $inputs&&$inputs.map(function (index,item) {
                    $(item).attr('disabled',false)
                })
            }else {
                //获取所有的input标签
                var $selfUl = $self.parents('ul'),
                    limitCount = $selfUl.find('.daiys').val(),
                    startTimeH = $selfUl.find('.timiys').val();


                var   r   =   /^[0-9]*[1-9][0-9]*$/;　　//正整数
                if(limitCount && !r.test(limitCount)){
                    new utils.MsgShow({
                        title:'当前放号天数必须大于0且为整数'
                    }).hideMsg()
                    return
                }

                if(limitCount >140){
                    new utils.MsgShow({
                        title:'当前放号天数最多为20周，即最大放号天数为140天'
                    }).hideMsg()
                    return
                }

                if(startTimeH && !r.test(startTimeH)){
                    new utils.MsgShow({
                        title:'可提前挂号时间必须大于0且为整数'
                    }).hideMsg()
                    return
                }


                var data = {
                    'outpatientId':hospitalId,
                    'days':limitCount || 7,
                    'leadTime':startTimeH || 30
                }

                console.log("data:",data)
                var popop = new utils.Popup({
                    msg:'<h2>时间编辑提示</h2><p>保存后时间会被修改</p>',
                    bCancel:true,
                    okText:'保存',
                    isHide:false,
                    okCallback:function (){
                        $.ajax({
                            type:'POST',
                            data:data,
                            url:'/treats/clinic/set_dayis',
                            success:function(json){
                                // console.log("json:",json)
                                if(json.success){
                                    new utils.MsgShow({
                                        title:'保存成功'
                                    }).hideMsg()
                                    popop.hideBox(function () {
                                        $inputs&&$inputs.map(function (index,item) {
                                            $(item).attr('disabled',true)
                                        });
                                        $self.addClass('updateBtn1').removeClass('saveBtn1').html('编辑')
                                    })
                                }else{
                                    new utils.MsgShow({
                                        title:json.msg
                                    }).hideMsg()
                                    popop.hideBox()
                                }
                            }
                        })
                    }
                })

            }
        })
        $body.on('click','.addbtn',function(){
            $(".mask").removeClass("none");
            $(".popupdiv").removeClass("none");
        })
        $body.on('click','.expressaddbtn',function(){
            $(".mask").removeClass("none");
            $(".del").removeClass("none");
        })
        $body.on('click','.close',function(){
            $(".mask").addClass("none");
            $(".popupdiv").addClass("none");
        })
        $body.on('click','.close1',function(){
            $(".mask").addClass("none");
            $(".del").addClass("none");
        })

        //上门取样点击提交
        $body.on('click','.push',function(){
            var hospitalId = $('.hospitalId').val();
            var type = $('.popupdiv').attr("type");
            var provinceid = $('.provincelabel').attr("provinceid");
            var cityid = $('.citylabel').attr("cityid");
            var qu = $('#site option:selected').attr("areaid");
            var insertServiceAreaRequest = {
                hospitalId:hospitalId,
                city:cityid,
                type:type,
                province:provinceid,
                district:qu
            }
            // console.log(insertServiceAreaRequest);
            $.ajax({
                type:'POST',
                data:insertServiceAreaRequest,
                url:'/treats/clinic/medical_serviceArea_add',
                success:function(json){
                    if(json.success){
                        new utils.MsgShow({
                            title:'添加成功'
                        }).hideMsg();
                        $(".mask").addClass("none");
                        $(".popupdiv").addClass("none");
                        window.location.reload();
                    }else{
                        $(".mask").addClass("none");
                        $(".popupdiv").addClass("none");
                        new utils.MsgShow({
                            title:json.msg
                        }).hideMsg()
                    }
                }
            })

        })

        //快递取样提交
        $body.on('click','.pushexpress',function(){
            var hospitalId = $('.hospitalId').val();
            var type = $('.del').attr("type");
            var provinceid = $('#express_province option:selected').attr("province");
            var city_id = $('#express_city option:selected').attr("city");
            var city_name = $('#express_city option:selected').val();
            console.log(city_name);
            console.log(city_id);
            var insertServiceAreaRequest = {
                hospitalId:hospitalId,
                city:city_id,
                type:type,
                province:provinceid,
                district:"0"
            }
            console.log(insertServiceAreaRequest);
            $.ajax({
                type:'post',
                data:insertServiceAreaRequest,
                url:'/treats/clinic/medical_serviceArea_add',
                success:function(json){
                    if(json.success){
                        new utils.MsgShow({
                            title:'添加成功'
                        }).hideMsg();
                        $(".mask").addClass("none");
                        $(".del").addClass("none");
                        window.location.reload();
                    }else{
                        $(".mask").addClass("none");
                        $(".del").addClass("none");
                        new utils.MsgShow({
                            title:json.msg
                        }).hideMsg()
                    }
                }
            })

        })

        //上门取样点击删除按钮
        $body.on('click','.delbtn',function(){
            var hospitalId = $('.hospitalId').val();
            var type = $('.popupdiv').attr("type");
            //获取选中的input的值
            var length = $('.siteContent tbody input[type="checkbox"]:checked').length;
            //可以一次性删除多个
            if(length==0){
                var tipText = "必须选中一行，且至少要选中一行";
                utils.AlertTip('fail', tipText);
                return false;
            }
            var wantData = [];
            $('.siteContent tbody input[type="checkbox"]:checked').each(function(index,item){
                var obj = {
                    areaId:$(item).closest("tr").attr("areaid"),
                    level:$(item).closest("tr").attr("level")
                }
                wantData.push(obj);
            })

            var data = {
                hospitalId:hospitalId,
                type:type,
                deleteServiceAreaRequestList:wantData

            }
            // console.log(data);
            $.ajax({
                type:'put',
                data:data,
                url:'/treats/clinic/serviceArea_batchDelete',
                success:function(json){
                    console.log(json)
                    if(json.success){
                        new utils.MsgShow({
                            title:'删除成功'
                        }).hideMsg();
                        $(".mask").addClass("none");
                        $(".del").addClass("none");
                        window.location.reload();
                    }else{
                        $(".mask").addClass("none");
                        $(".del").addClass("none");
                        new utils.MsgShow({
                            title:json.msg
                        }).hideMsg()
                    }
                }
            })

        })
        //快递取样点击删除按钮
        $body.on('click','.expressdelbtn',function(){
            var hospitalId = $('.hospitalId').val();
            var type = $('.del').attr("type");
            //获取选中的input的值
            var length = $('.expressContent tbody input[type="checkbox"]:checked').length;
            //可以一次性删除多个
            if(length==0){
                var tipText = "必须选中一行，且至少要选中一行";
                utils.AlertTip('fail', tipText);
                return false;
            }
            var wantData = [];
            $('.expressContent tbody input[type="checkbox"]:checked').each(function(index,item){
                var obj = {
                    areaId:$(item).closest("tr").attr("areaid"),
                    level:$(item).closest("tr").attr("level")
                }
                wantData.push(obj);
            })

            var data = {
                hospitalId:hospitalId,
                type:type,
                deleteServiceAreaRequestList:wantData

            }
            // console.log(data);
            $.ajax({
                type:'put',
                data:data,
                url:'/treats/clinic/serviceArea_batchDelete',
                success:function(json){
                    // console.log(json)
                    if(json.success){
                        new utils.MsgShow({
                            title:'删除成功'
                        }).hideMsg();
                        $(".mask").addClass("none");
                        $(".del").addClass("none");
                        window.location.reload();
                    }else{
                        $(".mask").addClass("none");
                        $(".del").addClass("none");
                        new utils.MsgShow({
                            title:json.msg
                        }).hideMsg()
                    }
                }
            })

        })

        //全选与反选
        $('#expresscheckbox input[type="checkbox"]').click(function(){
            if(this.checked){
                $('.expressContent tbody input[type="checkbox"]').each(function(index,item){
                    $(item).prop("checked",true);
                })
            }else{
                $('.expressContent tbody input[type="checkbox"]').each(function(index,item){
                    $(item).prop("checked",false);
                })
            }
            allchk("expressContent","expresscheckbox");
        })
        $('#sitecheckbox input[type="checkbox"]').click(function(){
            if(this.checked){
                $('.siteContent tbody input[type="checkbox"]').each(function(index,item){
                    $(item).prop("checked",true);
                })
            }else{
                $('.siteContent tbody input[type="checkbox"]').each(function(index,item){
                    $(item).prop("checked",false);
                })
            }
            allchk("siteContent","sitecheckbox");
        })
        $('.expressContent tbody input[type="checkbox"]').click(function(){
            allchk("expressContent","expresscheckbox");
        })
        $('.siteContent tbody input[type="checkbox"]').click(function(){
            allchk("siteContent","sitecheckbox");
        })
        function allchk(a,b){
            var chknum = $('.'+ a +' tbody input[type="checkbox"]').length;//选项总个数
            var chk = 0;
            $('.'+a+' tbody input[type="checkbox"]').each(function () {
                if($(this).prop("checked")==true){
                    chk++;
                }
            });
            if(chknum==chk){//全选
                $('#'+b+' input[type="checkbox"]').prop("checked",true);
            }else{//不全选
                $('#'+b+' input[type="checkbox"]').prop("checked",false);
            }
        }

        //快递取样，切换省份对应的城市也要进行切换
        $("#express_province").change(function(){
            var a=$("#express_province option:selected").attr("children");
            a = JSON.parse(a);
            var str = "";
            $.each(a,function(index,item){
                str += '<option value="'+item.name+'" city="'+item.id+'">'+item.name+'</option>'
            })
            // console.log(str);
            $("#express_city").html(str);
        })


    })



});
