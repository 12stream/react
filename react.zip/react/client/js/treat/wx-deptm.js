define(function (require, exports, module) {
  var utils = require('../utils')

  $(function () {
    var $body = $('body')
    var $add = $('.add-dpmt')
    var hospitalId = $('.hospitalId').val()
    var $cbList = $('.checkbox-list')

    var ctrl = {
      init: function () {
        ctrl.addDpmt()
        ctrl.editDpmt()
      },
      addDpmt: function () {
        var obj = {
          'id': '',
          'deptname': '',
          'order': '',
          'status': ''
        }
        var url = '/treats/add/wx/dept'
        $add.on('click', function () {
          ctrl.showPopup(obj, url)
        })
      },
      editDpmt: function () {
        var url = '/treats/edit/wx/dept'
        $cbList.on('click', '.checkbox', function (e) {
          e.preventDefault()
          var $this = $(this)
          var dataSet = $this.data()
          console.log(dataSet)
          ctrl.showPopup(dataSet, url)
        })
      },
      showPopup: function (obj, url) {
        if (obj.status == '1' || obj.status.length == 0) {
          var statusDOM = '<li><label>状态：</label><select name="status"><option selected value=1>启用</option><option value=2>禁用</option></select>'
        } else {
          var statusDOM = '<li><label>状态：</label><select name="status"><option value=1>启用</option><option value=2 selected>禁用</option></select>'
        }

        var popup = new utils.Popup({
          msg: '<h2>编辑</h2><ul>' +
            "<li><label>科室名称：</label><input type='hidden' class='hospitalId' name='hospitalId' value=" + hospitalId + "><input type='text' class='name' name='deptName' value=" + obj.deptname + '></li>' +
            "<li><label>排序：</label><input type='hidden' class='id' name='id' value=" + obj.id + "><input type='text' class='order' name='order' value=" + obj.order + '></li>' +
            statusDOM +
            '</ul>',
          otherBox: 'menuBox',
          okText: '提交',
          okCallback: function () {
            var serializeObj = {}
            $.each($('.menuBox').find('input,select'), function (index, item) {
              var key = $(item).attr('name')
              if ($(item).val()) {
                serializeObj[key] = $(item).val()
              }
            })

            console.log('serializeObj:', serializeObj)

            utils.SendAjax({
              url: url,
              method: 'POST',
              param: serializeObj,
              tipText: '编辑微信科室',
              callback: function (result) {
                var myMsg = new utils.MsgShow({
                  delayTime: 2000,
                  title: '编辑微信科室成功'
                }).hideMsg(function () {
                  popup.hideBoxNoTime()
                  window.location.reload()
                })
              }
            })
          }
        })
      }
    }
    ctrl.init()
  })
})
