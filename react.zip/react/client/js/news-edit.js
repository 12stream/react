define(function (require, exports, module) {
  var move = require('./move')
  var bootstrap = require('bootstrap')
  var utils = require('utils')
  var config = require('./config')
  var update = require('./update');
  require('./diyUpload.js')

  // $(function(){

  var ue = UE.getEditor('editor', {
    toolbars: [
      ['undo', 'redo', 'bold', 'italic', 'underline', 'fontsize', 'forecolor', 'backcolor', 'strikethrough', 'subscript',
        'fontborder', 'superscript', 'paragraph', 'link', 'unlink', 'simpleupload', 'lineheight',
        'justifyleft', 'justifyright', 'justifycenter'
      ]
    ],
    updateImages: function (file, ue, cb) {
      update.updateImages(file).then(function (result) {
        cb({
          state: 'SUCCESS',
          url: result.url,
          original: file.name,
        })
      })

    },
  })

  var saveUrl = $('#action').val()

  if (saveUrl == '/news/update') {
    new move.Move()
    var contentVal = $('#contentVal').val()
    if (contentVal) {
      ue.ready(function () {
        // 设置编辑器的内容
        ue.setContent(contentVal)
        var bool = $('#canEdit').val()
        if (bool == 'false') {
          bool = false
          ue.setDisabled()
        } else {
          bool = true
          ue.setEnabled()
          $('.show-save').show()
        }

      // 获取html内容，返回: <p>hello</p>
      // var html = ue.getContent()
      // 获取纯文本内容，返回: hello
      // var txt = ue.getContentTxt()
      })
    }
  }

  $('#title').on('blur', function () {
    checkInputStr('title', 1, 50)
  })
  $('#source').on('blur', function () {
    checkInputStr('source', 0, 50)
  })
  $('#keyword').on('blur', function () {
    checkInputStr('keyword', 0, 50)
  })
  $('#summary').on('blur', function () {
    checkInputStr('summary', 1, 255)
  })

  $('#submitBtn').on('click', function () {
    saveNews('submitBtn')
  })

  $('#draftBtn').on('click', function () {
    saveNews('draftBtn')
  })

  function saveNews (id) {
    // 输入验证
    var checkInput = true
    if (!checkInputStr('title', 1, 50)) {
      checkInput = false
    }
    if (!checkInputStr('source', 0, 50)) {
      checkInput = false
    }
    if (!checkInputStr('keyword', 0, 50)) {
      checkInput = false
    }
    // if (!checkInputStr('wapDesc', 0, 255)) {
    //   checkInput = false
    // }
    if (!checkInputStr('summary', 1, 255)) {
      checkInput = false
    }
    if (!checkInputStr('goodsImages', 1, 500)) {
      checkInput = false
    }

    if (checkInput == false) {
      utils.AlertTip('fail', '输入不符合规范,请检查')
      return false
    }

    var images = JSON.parse($('#goodsImages').val())
    // var imgs = []
    // if (images && images.length) {
    //   imgs.push(images[images.length - 1])
    // }
    var imgs = ''
    if (!images.length) {
      utils.AlertTip('fail', '请上传宣传图')
      return false
    } else {
      imgs = images[0].imageUrl
      if (!imgs) {
        var index = images.indexOf('com') + 3
        var content = images.substring(0, index)
        imgs = images.replace(content, '')
      }
    }
    $('#goodsImages').val(imgs)

    // if (id == 'submitBtn') {
    //   $('#postStatus').val('publish')
    // } else {
    //   $('#postStatus').val('draft')
    // }

    if (id == 'submitBtn') {
      // $('#postStatus').val('publish')

      // 已发布
      $('#status').val('2')
    } else {
      // $('#postStatus').val('draft')

      // 未发布
      $('#status').val('1')
    }

    var param = $('#newsForm').serialize()
    console.log(param)
    $('#' + id).addClass('disabled').off('click')
    utils.SendAjax({
      url: saveUrl,
      param: param,
      method: 'POST',
      tipText: '保存',
      callback: function (result) {
        utils.AlertTip('success', '保存成功', function () {
          $('#' + id).removeClass('disabled').off('click').on('click', function () {
            saveNews(id)
          })
          if (result.data.id) {
            window.location.href = '/news/list'
          } else {
            var id = $('#newsId').val()
            window.location.href = '/news/list'
          }
        })
      },
      errorFun: function () {
        $('#' + id).removeClass('disabled').off('click').on('click', function () {
          saveNews(id)
        })
      }
    })
  }

  $('#goodsImages').diyUpload({
    'bReplace': true,
    'browse_button': 'selectfiles_goodsImages',
    'postfiles': 'postfiles_goodsImages',
    'previewImageBox': 'previewImage_goodsImages',
    'stroageImgBtn': '#goodsImages',
    'businessId': 22001
  })

  function checkInputStr (id, smallNum, largenum) {
    var str = $('#' + id).val().trim()
    if (str.length < smallNum || str.length > largenum) {
      $('#' + id).closest('li').find('.tip').css('color', '#ee3e01')
      return false
    }
    $('#' + id).closest('li').find('.tip').css('color', '#333')
    return true
  }

  $('.edit-btn').on('click', function () {
    var $this = $(this)
    $this.hide()
    $('.show-save').show()
    canEdit(true)
  })

  canEdit($('#canEdit').val())

  function canEdit (bool) {
    if (bool == 'false') {
      bool = false
    } else {
      bool = true
      ue.setEnabled()
    }
    $('input, textarea').prop('readonly', !bool)
    $('select').prop('disabled', !bool)
  }
})
