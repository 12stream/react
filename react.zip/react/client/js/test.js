(function(){
    function add(a,b){
        return a+b;
    }
    add(10,100)
})(window)