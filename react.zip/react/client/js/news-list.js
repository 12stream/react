define(function (require, exports, module) {
  var utils = require('utils')
  var config = require('./config')

  // 获取所有类目
  var menudata = {'type': 'news_category','level': '1','activeState': '1'}
  utils.SendAjax({
    url: '/dataDic/category',
    param: menudata,
    tipText: '获取类目',
    callback: function (result) {
      var options = result.data
      // var parentId = options[0].parentId
      var html = "<option value='all'>全部</option>"
      for (var i = 0; i < options.length; i++) {
        var selectedCat = $('#selectedCat').val()
        if (selectedCat == options[i].id) {
          html += "<option value='" + options[i].id + "' selected>" + options[i].name + '</option>'
        }else {
          html += "<option value='" + options[i].id + "'>" + options[i].name + '</option>'
        }
      }
      $('#category').html(html)
    // $('#selectedCat').val(parentId)
    }
  })

  var selectedPostStatus = $('#selectedPostStatus').val()
  // $("#publishState option[value=" + selectedPostStatus +"]").attr('selected','selected')
  $('#publishState option[value=' + selectedPostStatus + ']').attr('selected', 'selected')

  $('.edit').on('click', function (e) {
    e.stopPropagation()
    e.preventDefault()
    var idVal = $(this).parent().find('.idVal').val()
    window.location.href = '/kepu/modifyView?id=' + idVal
  })

  $('.cancelPub').on('click', function (e) {
    changeNewsState(e, this, '取消发布', 'postStatus', 'pending')
  })

  $('.pub').on('click', function (e) {
    changeNewsState(e, this, '发布', 'postStatus', 'pending')
  })

  function changeNewsState (e, obj, tipText, paramKey, paramValue) {
    e.stopPropagation()
    e.preventDefault()
    var popup = new utils.Popup({
      msg: '确定' + tipText + '该文章吗？',
      okText: '确定' + tipText,
      okCallback: function () {
        // var idVal = $(obj).parent().find('.idVal').val()
        var idVal = $(obj).data('id')
        var status = $(obj).data('status')
        var param = {status: status, id: idVal}
        // param[paramKey] = paramValue
        utils.SendAjax({
          url: '/news/change/state',
          method: 'PUT',
          param: param,
          tipText: tipText,
          callback: function () {
            window.location.reload()
          }
        })
      }
    })
  }

  function deleteNews (tipText) {
    $('.delete').on('click', function (e) {
      e.stopPropagation()
      e.preventDefault()
      var $this = $(this)
      var popup = new utils.Popup({
        msg: '确定' + tipText + '该文章吗？',
        okText: '确定' + tipText,
        okCallback: function () {
          // var idVal = $(obj).parent().find('.idVal').val()
          var idVal = $this.data('id')
          // var status = $(obj).data('status')
          var param = {id: idVal}
          // param[paramKey] = paramValue
          utils.SendAjax({
            url: '/news/delete',
            method: 'PUT',
            param: param,
            tipText: tipText,
            callback: function () {
              // new utils.Popup({
              //   msg: tipText + '成功'
              // })
              window.location.reload()
            }
          })
        }
      })
    })
  }
  deleteNews('删除')
})
