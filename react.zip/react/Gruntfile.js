//包装函数
module.exports = function(grunt){
    //配置任务，所有插件的配置信息
    grunt.initConfig({
        //获取package.json的信息
        pkg:grunt.file.readJSON('package.json'),
        //uglify插件的配置信息 压缩js代码
        uglify:{
            options:{
                stripBanner:true,
                banner:''
            },
            build:{
                src:'public/js/test.js',
                dest:'build/<%=pkg.name%>-<%=pkg.version%>.min.js'
            }
        },
        //jshint插件（检查javascript语法错误）
        jshint:{
            build:['Gruntfile.js','public/js/*.js'],
            options:{
                jshintrc:'.jshintrc'
            }
        },
        //watch插件（实现自动化）
        watch:{
            jade: {
                files: ['app/views/**'],
                options: {
                    livereload: true
                }
            },
            js: {
                files: ['public/js/**', 'app/models/**/*.js', 'schemas/**/*.js'],
                // tasks:['jshint'],
                options: {
                    livereload: true
                }
            }
        },
        nodemon: {
            dev: {
                script: 'app.js',
                options: {
                    args: [],
                    nodeArgs: ['--debug'],
                    ignore: ['README.md', 'node_modules/**', '.DS_Store'],
                    ext: 'js',
                    watch: ['./'],
                    delay: 1000,
                    env: {
                        PORT: '3000'
                    },
                    cwd: __dirname,
                    legacyWatch: true
                }
            }
        },
        concurrent: {
            tasks: ['nodemon', 'watch'],
            options: {
                logConcurrentOutput: true
            }
        }
    });

    grunt.loadNpmTasks('grunt-contrib-watch')  //有文件添加修改，删除，就会重新执行任务

    grunt.loadNpmTasks('grunt-nodemon'); //文件改变后，会自动启动服务

    grunt.loadNpmTasks('grunt-concurrent'); // Run grunt tasks concurrently 并发执行任务

    //告诉grunt 使用插件
    grunt.loadNpmTasks('grunt-contrib-uglify')
    //告诉grunt 当我们在终端输入grunt时候需要做些什么 （注意先后顺序）

    grunt.option('force',true); //避免编译的时候出现错误而中断服务
    //在grunt命令执行时，要不要立即执行uglify插件？如果要，就写上，否则不写。我现在是需要的，所以我写上。也有可能不需要，这种情况谁知道呢
    grunt.registerTask('default',['concurrent']);
}